<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Restaurant Apps Starter Project</title>
    <link rel="manifest" href="manifest.json">
    <meta name="theme-color" content="#232528" />
    <link rel="apple-touch-icon" href="/icons/icon-192x192.png">
    <script src="https://use.fontawesome.com/b070c8f1df.js"></script>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
    <link rel="stylesheet" href="<?php echo e(URL::asset('style/style.css')); ?>" />
</head>

<body>
    <header>
        <div class="container">
            <nav class="navbar">
                <a href="" class="skip-link">Go To Content</a>
                <a href="#" class="logo">
                    <h1>Hunger Apps</h1>
                </a>
                <input type="checkbox" id="tab-nav" class="tab-nav">
                <button class="nav-menu"><i class="material-icons">reorder</i></button>
                <ul class="nav-list">
                    <li class="nav-item">
                        <a href="#/home" class="nav-link">Home</a>
                    </li>
                    <li class="nav-item">
                        <a href="#/favorite" class="nav-link">Favorite</a>
                    </li>
                    <li class="nav-item">
                        <a href="https://www.linkedin.com/in/rifqi-arrahim-983935112/" class="nav-link">About Us</a>
                    </li>
                </ul>
            </nav>
        </div>
    </header>
    <div class="loader">
        <div></div>
    </div>
    <main id="maincontent"></main>
    <footer>
        <section id="about" class="about">
            <h2 tabindex="0">Hunger Apps</h2>
            <p tabindex="0"> Lorem ipsum dolor sit amet consectetur adipisicing elit. Quasi non voluptatum provident cum totam expedita aperiam quia sequi delectus.</p>
            <ul class="socials">
                <li><a id="facebook" href="https://www.facebook.com/muhamad.rifqi.353/" aria-label="Our Facebook"><i class="fa fa-facebook"></i></a></li>
                <li><a href="https://www.youtube.com/channel/UC4aoBf1hBau0DZnwufoeZ0Q" aria-label="Our youtube"><i class="fa fa-youtube"></i></a></li>
                <li><a href="https://www.linkedin.com/in/rifqi-arrahim-983935112/" aria-label="Our linkedin"><i class="fa fa-linkedin-square"></i></a></li>
            </ul>
            <div class="footer-bootom">
                <p tabindex="0" aria-label="copyrigth 2020 Hunger Apps">copyrigth &copy;2020 - Hunger Apps</p>
            </div>
        </section>
    </footer>
</body>

</html><?php /**PATH C:\xampp_n\htdocs\TUBES\resources\views/welcome.blade.php ENDPATH**/ ?>