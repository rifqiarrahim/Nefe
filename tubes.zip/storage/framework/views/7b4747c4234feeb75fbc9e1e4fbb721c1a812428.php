

<?php $__env->startSection('container'); ?>
<div class="container">

    <div id="carouselExampleControls" class="carousel slide mt-3 carousel-dark" style="background: #FBF8F1;" data-bs-ride="carousel">
        <div class="carousel-inner">
            <div class="carousel-item active">
                    <img src="<?php echo e(asset('/img/DSC_0331 (Small).jpg')); ?>" class="d-block mx-auto "style="min-height: 200px;max-height:400px"  alt="...">
            </div>
            <div class="carousel-item">
                <img src="<?php echo e(asset('/img/foto1 (Small).jpg')); ?>" class="d-block mx-auto "style="min-height: 200px;max-height:400px"  alt="...">
            </div>
            <div class="carousel-item">
                <img src="<?php echo e(asset('/img/foto2 (Small).jpg')); ?>" class="d-block mx-auto"style="min-height: 200px;max-height:400px"  alt="...">
            </div>
            <div class="carousel-item">
                <img src="<?php echo e(asset('/img/foto3 (Small).jpg')); ?>" class="d-block mx-auto"style="min-height: 200px;max-height:400px"  alt="...">
            </div>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls"
            data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls"
            data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
        </button>
    </div>
    
    <div class="col">
        <h2><?php echo e($Cafe['name']); ?></h2>
        <div class="row">
            <div class="col-md-6">
                <i class="bi bi-star-fill"></i>
                <?php echo e($rating); ?>

                <h4 class="mt-0">Rating</h4>
            </div>
            <div class="col-md-6">
                <i class="bi bi-hand-thumbs-up-fill"></i>
                <?php echo e($like); ?>

                <h4>Likes</h4>
            </div>
        </div>
        <h3>Address</h3>
        <p><?php echo e($Cafe['address']); ?></p>
        <h3>Description</h3>
        <p><?php echo e($Cafe['description']); ?></p>
        <h3>Review</h3>
        <?php $__currentLoopData = $Cafe->review; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card mt-1">
            <div class="card-body">
                <h5 class="card-title"><?php echo e($review->user['name']); ?></h5>
                <p class="card-text"><?php echo e($review['comment']); ?></p>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <form action="/cafe/{$Cafe['id']}" method="POST" class="mt-2">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-7">
                    <div class="mb-3">
                        <input type="hidden" id="userId" name="user_id" value="<?php echo e(auth()->user()->id); ?>">
                        <input type="hidden" id="cafeId" name="cafe_id" value="<?php echo e($Cafe['id']); ?>">
                        <input type="text" class="form-control <?php $__errorArgs = ['comment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="commentLabel"
                            name="comment" value="<?php echo e(old('comment')); ?>" placeholder="Add Comment...">
                        <?php $__errorArgs = ['comment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    
                </div>
                <div class="col-5">
                    <div class="row">
                        <div class="col-4">
                            
                            
                            <select class="form-select" name="rating">
                                <option value="1">One Star</option>
                                <option value="2">Two Stars</option>
                                <option value="3">Three Stars</option>
                                <option value="4">Four Stars</option>
                                <option value="5">Five Stars</option>
                            </select>
                        </div>
                        <div class="col-2 d-flex justify-content-center align-items-center">
                                <input type="checkbox" id="likeBox" name="like" class="form-check-input">
                                <label for="likeBox" class="form-check-label bi bi-hand-thumbs-up-fill"></label>
                        </div>
                        <div class="col-6">
                            <button type="submit" class="btn btn-success bi bi-pencil fs-8"> Comment & Rating</button>
                        </div>
                    </div>
                </div>
            </div>
        </form>
        <div class="d-flex justify-content-start mb-3">
            <button type="button" class="btn btn-success"><a href="/"
                    style="text-decoration: none; color:whitesmoke;"><i class="bi bi-arrow-left"></i> Back to
                    home</a></button>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_n\htdocs\TUBES\resources\views/cafe.blade.php ENDPATH**/ ?>